package org.depaul.logic.events;

public enum EventType {
    DOWN
}
