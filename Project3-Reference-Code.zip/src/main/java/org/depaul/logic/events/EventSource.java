package org.depaul.logic.events;

public enum EventSource {
    USER, THREAD
}
