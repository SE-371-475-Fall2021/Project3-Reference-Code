package org.depaul.logic.rotator;

import org.junit.Assert;
import org.junit.Test;

public class NextShapeInfoTest {


    @Test
    public void testGetPosition() {

    }
}